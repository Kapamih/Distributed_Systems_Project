//GLOB

package com.example.spotifypro;

import android.media.MediaPlayer;

public class Glob {
    public static boolean firstTime=true;
    public static boolean songFound=true;
    public static Consumer cons;
    public static MediaPlayer mediaPlayer =new MediaPlayer();

}
