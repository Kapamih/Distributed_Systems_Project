# 2η ΦΑΣΗ

## intellij

* Αλλαγή στο *brokers.txt* στις IP -> ο καθένας βάζει την IP του PC του (οι αντίστοιχες αλλαγές να γίνουν και στον κώδικα)
* Δημιουργία *package* (μέσα στον φάκελο src) που θα περιέχει μόνο τα αρχεία java.
* To package θα πρέπει να έχει το ίδιο όνομα με το package στο project του Android.
* Για να μήν αλλάζουμε όλα τα Path αρκεί να:
  * αφήσουμε τον φάκελο *Songs* έξω από το *src*,
  * αφήσουμε το *brokers.txt* μέσα στο *src* χωρίς να το βάλουμε μέσα στο package.
* Ορίζουμε το N στο Node.java.

## Android Studio

* Pixel 2 API R (Running Device)
* Αλλαγή της IP στο *ArtistList.java* -> ο καθένας βάζει την IP του PC του. (Στην MyFirstTask)
* Ορίζουμε το N στο Node.java.


**(Αν έχει μαύρη οθόνη)**
